.. _logic:

======
Logic
======

**Contents**

.. toctree::
   :titlesonly:

   ../../../modules/logic.rst
   ../../../modules/sets.rst
