.. _topics:

======
Topics
======

**Contents**

.. toctree::
   :titlesonly:

   ../../../modules/geometry/index.rst
   ../../../modules/holonomic/index.rst
   ../../../modules/liealgebras/index.rst
   ../../../modules/polys/index.rst
   ../../../modules/categories.rst
   ../../../modules/crypto.rst
   ../../../modules/diffgeom.rst
   ../../../modules/plotting.rst
   ../../../modules/stats.rst
