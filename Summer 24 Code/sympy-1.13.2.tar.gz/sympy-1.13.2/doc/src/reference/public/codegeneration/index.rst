.. _codegen_module:

===============
Code Generation
===============

**Contents**

.. toctree::
   :titlesonly:

   ../../../modules/codegen.rst
