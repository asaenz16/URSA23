Matrix Kind
===========

.. module:: sympy.matrices.kind

.. autoclass:: MatrixKind
   :members:
   :special-members:
   :inherited-members:
