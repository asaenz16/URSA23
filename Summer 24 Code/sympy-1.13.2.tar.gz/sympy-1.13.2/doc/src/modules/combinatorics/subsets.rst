.. _combinatorics-subsets:

Subsets
=======

.. module:: sympy.combinatorics.subsets

.. autoclass:: Subset
   :members:

.. automethod:: sympy.combinatorics.subsets.ksubsets
