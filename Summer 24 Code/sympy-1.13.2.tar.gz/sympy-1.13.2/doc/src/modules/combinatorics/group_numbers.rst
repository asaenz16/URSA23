.. _combinatorics-group_numbers:

Number of groups
================

.. module:: sympy.combinatorics.group_numbers

.. autofunction:: is_nilpotent_number

.. autofunction:: is_abelian_number

.. autofunction:: is_cyclic_number

.. autofunction:: groups_count
