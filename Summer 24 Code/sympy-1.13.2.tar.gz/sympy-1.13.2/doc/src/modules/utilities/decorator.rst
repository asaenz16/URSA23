=========
Decorator
=========

.. automodule:: sympy.utilities.decorator
   :members:
   :exclude-members: deprecated

   .. autodecorator:: sympy.utilities.decorator.deprecated
