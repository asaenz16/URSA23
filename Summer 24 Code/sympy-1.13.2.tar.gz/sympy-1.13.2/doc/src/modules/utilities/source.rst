======================
Source Code Inspection
======================

.. automodule:: sympy.utilities.source
   :members:
