.. _testing-docs:

=======
Testing
=======

.. TODO: add  benchmarking.rst

.. automodule:: sympy.testing

Contents:

.. toctree::
   :titlesonly:

   pytest.rst
   randtest.rst
   runtests.rst
