========
Simplify
========

.. toctree::
   :titlesonly:

   simplify.rst
   hyperexpand.rst
   fu.rst
