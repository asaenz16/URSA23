.. _holonomic-docs:

=========
Holonomic
=========

.. automodule:: sympy.holonomic

Contents
========

.. toctree::
   :titlesonly:

   about.rst
   represent.rst
   operations.rst
   convert.rst
   uses.rst
   internal.rst
