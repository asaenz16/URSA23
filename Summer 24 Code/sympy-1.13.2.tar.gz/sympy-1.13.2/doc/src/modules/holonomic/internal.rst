Internal API
============

.. autofunction:: sympy.holonomic.holonomic._create_table

.. autofunction:: sympy.holonomic.holonomic._convert_poly_rat_alg
