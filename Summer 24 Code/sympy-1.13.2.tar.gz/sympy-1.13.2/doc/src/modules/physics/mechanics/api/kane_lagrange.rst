.. _kane_lagrange:

==============================================
Kane's Method & Lagrange's Method (Docstrings)
==============================================

.. automodule:: sympy.physics.mechanics.kane
   :members:

.. automodule:: sympy.physics.mechanics.lagrange
   :members:
