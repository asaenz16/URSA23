===================
System (Docstrings)
===================

.. autoclass:: sympy.physics.mechanics.system.SymbolicSystem
   :members:

.. autoclass:: sympy.physics.mechanics.system.System
   :members:
