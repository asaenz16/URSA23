==========================
Linearization (Docstrings)
==========================

.. automodule:: sympy.physics.mechanics.linearize
   :members:
   :special-members: __init__
