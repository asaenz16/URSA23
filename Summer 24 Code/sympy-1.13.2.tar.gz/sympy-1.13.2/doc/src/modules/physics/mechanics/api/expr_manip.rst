====================================
Expression Manipulation (Docstrings)
====================================

.. autofunction:: sympy.physics.mechanics.msubs

.. autofunction:: sympy.physics.mechanics.find_dynamicsymbols
