==============================
Wrapping Geometry (Docstrings)
==============================

.. automodule:: sympy.physics.mechanics.wrapping_geometry
   :members:
