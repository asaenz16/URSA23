=======
Control
=======

.. module:: sympy.physics.control

.. topic:: Abstract

    Contains docstrings of Physics-Control module


.. toctree::
   :titlesonly:

   control.rst
   lti.rst
   control_plots.rst
