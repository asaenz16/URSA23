.. _physics_high_energy_physics:

===================
High Energy Physics
===================

.. topic:: Abstract

   Contains docstrings for methods in high energy physics.

Gamma matrices
==============

.. automodule:: sympy.physics.hep.gamma_matrices
    :members:
