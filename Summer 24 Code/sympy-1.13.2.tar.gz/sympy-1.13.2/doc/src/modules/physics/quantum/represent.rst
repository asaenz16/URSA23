=========
Represent
=========

.. automodule:: sympy.physics.quantum.represent
   :members:
