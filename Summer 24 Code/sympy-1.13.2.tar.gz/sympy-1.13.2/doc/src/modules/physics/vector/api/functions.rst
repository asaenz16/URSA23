================================
Essential Functions (Docstrings)
================================

.. autofunction:: sympy.physics.vector.dynamicsymbols

.. autofunction:: sympy.physics.vector.functions.dot

.. autofunction:: sympy.physics.vector.functions.cross

.. autofunction:: sympy.physics.vector.functions.outer

.. autofunction:: sympy.physics.vector.functions.express

.. autofunction:: sympy.physics.vector.functions.time_derivative
