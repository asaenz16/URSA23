=================
Essential Classes
=================

.. autoclass:: sympy.physics.vector.frame.CoordinateSym
   :members:

.. autoclass:: sympy.physics.vector.frame.ReferenceFrame
   :members:
   :exclude-members: orient_explicit

.. autoclass:: sympy.physics.vector.vector.Vector
   :members:

.. autoclass:: sympy.physics.vector.dyadic.Dyadic
   :members:
