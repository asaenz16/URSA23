=======================
Activation (Docstrings)
=======================

.. automodule:: sympy.physics.biomechanics.activation
   :members:
