==========================
Musculotendon (Docstrings)
==========================

.. automodule:: sympy.physics.biomechanics.musculotendon
   :members:
