=================
Beam (Docstrings)
=================

.. automodule:: sympy.physics.continuum_mechanics.beam
   :members:
