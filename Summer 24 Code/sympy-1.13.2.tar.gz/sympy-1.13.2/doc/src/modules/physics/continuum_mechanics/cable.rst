==================
Cable (Docstrings)
==================

Cable
=====

.. automodule:: sympy.physics.continuum_mechanics.cable
   :members:
