=======================
N-dim array expressions
=======================

.. automodule:: sympy.tensor.array.expressions

.. autoclass:: sympy.tensor.array.expressions.ArrayTensorProduct
.. autoclass:: sympy.tensor.array.expressions.ArrayContraction
.. autoclass:: sympy.tensor.array.expressions.ArrayDiagonal
.. autoclass:: sympy.tensor.array.expressions.PermuteDims
