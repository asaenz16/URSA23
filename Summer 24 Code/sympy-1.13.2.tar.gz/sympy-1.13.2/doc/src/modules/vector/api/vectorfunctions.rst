================================================
Essential Functions in sympy.vector (docstrings)
================================================


.. autofunction:: sympy.vector.matrix_to_vector

.. autofunction:: sympy.vector.express

.. autofunction:: sympy.vector.curl

.. autofunction:: sympy.vector.divergence

.. autofunction:: sympy.vector.gradient

.. autofunction:: sympy.vector.is_conservative

.. autofunction:: sympy.vector.is_solenoidal

.. autofunction:: sympy.vector.scalar_potential

.. autofunction:: sympy.vector.scalar_potential_difference

.. autofunction:: sympy.vector.integrals.vector_integrate
