=============================
Orienter classes (docstrings)
=============================

.. autoclass:: sympy.vector.orienters.Orienter
   :members:

.. autoclass:: sympy.vector.orienters.AxisOrienter
   :members:

   .. automethod:: sympy.vector.orienters.AxisOrienter.__init__

.. autoclass:: sympy.vector.orienters.BodyOrienter
   :members:

   .. automethod:: sympy.vector.orienters.BodyOrienter.__init__

.. autoclass:: sympy.vector.orienters.SpaceOrienter
   :members:

   .. automethod:: sympy.vector.orienters.SpaceOrienter.__init__

.. autoclass:: sympy.vector.orienters.QuaternionOrienter
   :members:

   .. automethod:: sympy.vector.orienters.QuaternionOrienter.__init__
