For instructions on installation, building the documentation, and guidelines for
contributing to SymPy's documentation, please read the `SymPy Documentation
Style Guide <https://docs.sympy.org/dev/documentation-style-guide.html>`_.

The SymPy Documentation Style Guide can also be read at
src/documentation-style-guide.rst.
